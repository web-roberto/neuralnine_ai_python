from .celery import celery_app as celery  # NOTE: New addition
